import pytest

from main import extract_pr_gen_fuel, transform_pr_gen_fuel


@pytest.fixture
def monthly_clean():
    # Read in the raw data...
    raw_pr_gen_fuel, raw_pr_plant_frame = extract_pr_gen_fuel()
    # Then run the code...
    pr_gen_fuel = transform_pr_gen_fuel(raw_pr_gen_fuel, raw_pr_plant_frame)[0]
    return pr_gen_fuel


def test_renewables_fuel_units(monthly_clean):
    # Pull out the subset we care about...
    renewable_codes = {"SUN", "WND", "WAT"}
    renewable_gen_fuels = monthly_clean[
        monthly_clean["energy_source_code"].isin(renewable_codes)
    ]
    renewable_fuel_units = renewable_gen_fuels["fuel_consumed_units"]
    # Finally, assert something!
    assert (renewable_fuel_units.dropna() == 0).all()


def get_heat_rates(monthly, source_codes):
    filtered = monthly.loc[monthly.energy_source_code.isin(source_codes)]
    generation_kwh = filtered["net_generation_mwh"] * 1_000
    consumption_btu = filtered["fuel_consumed_for_electricity_mmbtu"] * 1_000_000
    heat_rate = consumption_btu / generation_kwh
    return heat_rate


def test_heat_rates(monthly_clean):
    """Check that heat rates of fossil fuels are somewhat reasonable.

    Because

    Heat rates are typically represented as BTU per kWh.
    """
    fossil_source_codes = {"DFO", "RFO", "NG", "BIT"}
    renewable_source_codes = {"SUN", "WND", "WAT"}
    years_to_check = [2017, 2018, 2019, 2020, 2021]
    for year in years_to_check:
        one_year_gen_fuel = monthly_clean.loc[monthly_clean.date.dt.year == year]
        fossil_fuel_heat_rates = get_heat_rates(one_year_gen_fuel, fossil_source_codes)
        renewable_heat_rates = get_heat_rates(one_year_gen_fuel, renewable_source_codes)

        assert fossil_fuel_heat_rates.mean() == renewable_heat_rates.mean()
