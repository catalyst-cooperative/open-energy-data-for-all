def inner_func(x, y):
    return f"({x}, {y})"


def outer_func():
    x = 1
    breakpoint()
    y = x + 1
    z = inner_func(x, y)
    return z


if __name__ == "__main__":
    outer_func()

