def main():
    print("Hello from pr-gen-fuel!")


if __name__ == "__main__":
    main()
