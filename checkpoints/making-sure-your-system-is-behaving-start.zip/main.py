import pandas as pd
import numpy as np
from utils import handle_data_types, melt_monthly_vars

# Silence some warnings about deprecated Pandas behavior
pd.set_option("future.no_silent_downcasting", True)


def extract_pr_gen_fuel():
    # Read in the raw data
    pr_gen_fuel = pd.read_parquet(
        "data/raw_eia923__puerto_rico_generation_fuel.parquet"
    )
    pr_plant_frame = pd.read_parquet("data/raw_eia923__puerto_rico_plant_frame.parquet")
    return pr_gen_fuel, pr_plant_frame


def transform_pr_gen_fuel(pr_gen_fuel, pr_plant_frame):
    # Handle EIA null values
    pr_gen_fuel = pr_gen_fuel.replace(to_replace=".", value=pd.NA)

    # Convert data types (mmbtu/units to numeric, booleans, categories)
    pr_gen_fuel = handle_data_types(
        pr_gen_fuel,
        categorical_cols=[
            "energy_source_code",
            "fuel_type_code_agg",
            "prime_mover_code",
            "reporting_frequency_code",
            "data_maturity",
            "plant_state",
        ],
    )

    for colname in pr_gen_fuel.columns:
        if (
            "fuel_consumption" in colname
            or "fuel_consumed" in colname
            or "net_generation" in colname
            or "fuel_mmbtu_per_unit" in colname
        ):
            pr_gen_fuel[colname] = pr_gen_fuel[colname].astype("float64")

    # Handle EIA null values
    pr_plant_frame = pr_plant_frame.replace(to_replace=".", value=pd.NA)

    # Convert data types (mmbtu/units to numeric, categories, booleans)
    pr_plant_frame_final = handle_data_types(
        pr_plant_frame,
        categorical_cols=["reporting_frequency_code", "data_maturity", "plant_state"],
    )

    #### monthly pivoting
    # Pivot variable columns
    fuel_elec_mmbtu_melt = melt_monthly_vars(
        pr_gen_fuel, "fuel_consumed_for_electricity_mmbtu"
    )
    fuel_elec_units_melt = melt_monthly_vars(
        pr_gen_fuel, "fuel_consumed_for_electricity_units"
    )
    fuel_mmbtu_melt = melt_monthly_vars(pr_gen_fuel, "fuel_consumed_mmbtu")
    fuel_units_melt = melt_monthly_vars(pr_gen_fuel, "fuel_consumed_units")
    net_gen_melt = melt_monthly_vars(pr_gen_fuel, "net_generation_mwh")

    # Combine all the pivoted DFs
    pr_gen_fuel_melt = pd.concat(
        [
            fuel_elec_mmbtu_melt,
            fuel_elec_units_melt,
            fuel_mmbtu_melt,
            fuel_units_melt,
            net_gen_melt,
        ],
        axis="columns",
    ).reset_index()

    ## Create date from month and year
    pr_gen_fuel_melt["date"] = pd.to_datetime(
        pr_gen_fuel_melt["month"] + pr_gen_fuel_melt["report_year"].astype(str),
        format="%B%Y",
    )
    ## Drop old date columns
    pr_gen_fuel_clean = pr_gen_fuel_melt.drop(columns=["report_year", "month"])

    # Plant 62410 has two 2020 data entries but one is null
    # Drop the bad row
    pr_gen_fuel_final = pr_gen_fuel_clean.loc[
        ~(
            (pr_gen_fuel_clean.plant_id_eia == 62410)
            & (pr_gen_fuel_clean.date.dt.year == 2020)
            & (pr_gen_fuel_clean.fuel_consumed_for_electricity_mmbtu.isnull())
        )
    ]

    # drop after 2025-03-01 (for now) as these values should not exist
    pr_gen_fuel_final = pr_gen_fuel_final.loc[
        pr_gen_fuel_clean.date < pd.Timestamp("2025-03-01")
    ]
    return pr_gen_fuel_final, pr_plant_frame_final


def load_pr_gen_fuel(pr_gen_fuel_final, pr_plant_frame_final):
    ### output the data to Parquet files
    pr_gen_fuel_final.to_parquet("data/pr_gen_fuel_monthly.parquet")
    pr_plant_frame_final.to_parquet("data/pr_plant_frame.parquet")


if __name__ == "__main__":
    pr_gen_fuel, pr_plant_frame = extract_pr_gen_fuel()
    pr_gen_fuel_final, pr_plant_frame_final = transform_pr_gen_fuel(
        pr_gen_fuel, pr_plant_frame
    )
    load_pr_gen_fuel(pr_gen_fuel_final, pr_plant_frame_final)
